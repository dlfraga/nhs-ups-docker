$(function() {
  var intervalo = $('#intervalo').val();
  intervalo = parseInt(intervalo) * 1000;
  $(document).everyTime(intervalo, function(i) {
    $('#form_intervalo').get(0).submit();
  });

  $('#intervalo').change(function() {
    $('#form_intervalo').get(0).submit();
  });
});

