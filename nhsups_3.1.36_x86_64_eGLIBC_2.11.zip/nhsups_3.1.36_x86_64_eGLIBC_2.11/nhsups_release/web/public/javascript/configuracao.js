function toogle_eventos(element_name) {
  var e = $('#' + element_name);
  if (e.css('display') == 'none')
    e.css('display', '');
  else
    e.css('display', 'none');
}

$(function() {
  $('#link_eventos1').click(function() { toogle_eventos('eventos1') });
  $('#link_eventos2').click(function() { toogle_eventos('eventos2') });
  $('#link_eventos3').click(function() { toogle_eventos('eventos3') });
  $('#link_eventos4').click(function() { toogle_eventos('eventos4') });
});

