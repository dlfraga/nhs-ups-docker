function selectAll() {
  $(':checkbox').attr('checked', true);
}

function clearAll() {
  $(':checkbox').attr('checked', false);
}

