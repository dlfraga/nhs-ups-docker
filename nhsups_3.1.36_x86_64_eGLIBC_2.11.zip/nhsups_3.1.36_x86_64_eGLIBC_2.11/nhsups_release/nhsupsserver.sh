#!/bin/sh -e

### BEGIN INIT INFO
# Provides:             nhsupsserver
# Required-Start:       $local_fs $remote_fs $network
# Required-Stop:        $local_fs $remote_fs $network
# Default-Start:        2 3 4 5
# Default-Stop:         0 1 6
# Short-Description:    NHS UPS Server
### END INIT INFO

NHSUPSSERVER=/usr/local/nhs/nhsupsserver
PIDFILE=/var/lib/nhsups/nhsupsserver.pid

do_start()
{
    $NHSUPSSERVER -d
}

do_stop()
{
    if [ -e $PIDFILE ]; then
        kill $(cat $PIDFILE)
        rm $PIDFILE
    fi
}

do_pid_check()
{
	PROCESS_SERVER_UP=`ps aux | grep -i nhsupsserver | grep -v 'grep' | grep -v 'sh' | awk '{print $11}'`

        if [ -z "$PROCESS_SERVER_UP" ]
        then
                rm -f /var/lib/nhsups/nhsupsserver.pid
        fi
}

case "$1" in
    start)
        do_pid_check
	do_start
        ;;
    stop)
        do_stop
        ;;
    restart | reload | force-reload)
        do_stop
        sleep 2
        do_pid_check
        do_start
        ;;
    status)
        if [ -e $PIDFILE ]; then
            echo "Serviço iniciado.";
        else
            echo "Serviço parado.";
        fi
        ;;
    *)
        echo "Uso: $0 {start|stop|restart|reload|force-reload|status}"
        exit 1
        ;;
esac

exit 0
