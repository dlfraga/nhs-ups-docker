#!/bin/sh -e

### BEGIN INIT INFO
# Provides:             nhsupsclient
# Required-Start:       $local_fs $remote_fs $network
# Required-Stop:        $local_fs $remote_fs $network
# Default-Start:        2 3 4 5
# Default-Stop:         0 1 6
# Short-Description:    NHS UPS Client
### END INIT INFO

NHSUPSCLIENT=/usr/local/nhs/nhsupsclient
PIDFILE=/var/lib/nhsups/nhsupsclient.pid

do_start()
{
    $NHSUPSCLIENT -d
}

do_stop()
{
    if [ -e $PIDFILE ]; then
        kill $(cat $PIDFILE)
        rm $PIDFILE
    fi
}

do_pid_check()
{
        PROCESS_CLIENT_UP=`ps aux | grep -i nhsupsclient | grep -v 'grep' | grep -v 'sh' | awk '{print $11}'`

        if [ -z "$PROCESS_CLIENT_UP" ]
        then
                rm -f /var/lib/nhsups/nhsupsclient.pid
        fi
}


case "$1" in
    start)
        do_pid_check
	do_start
        ;;
    stop)
        do_stop
        ;;
    restart | reload | force-reload)
        do_stop
        sleep 2
        do_pid_check
        do_start
        ;;
    status)
        if [ -e $PIDFILE ]; then
            echo "Serviço iniciado.";
        else
            echo "Serviço parado.";
        fi
        ;;
    *)
        echo "Uso: $0 {start|stop|restart|reload|force-reload|status}"
        exit 1
        ;;
esac

exit 0
