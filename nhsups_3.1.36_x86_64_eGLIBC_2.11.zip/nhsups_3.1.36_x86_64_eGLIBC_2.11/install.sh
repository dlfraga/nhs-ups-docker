#!/usr/bin/env sh
LOCALDIR=/usr/local
DESTDIR=$LOCALDIR/nhs
cp -R nhsups_release $LOCALDIR || exit 1
mv $LOCALDIR/nhsups_release $DESTDIR || exit 1
echo Os arquivos dos serviços de monitoramento foram copiados para
echo $DESTDIR.
echo
echo Configure agora os serviços 'nhsupsserver' e 'nhsupsclient' para a
echo sua plataforma. Use os scripts $DESTDIR/nhsupsserver.sh e
echo $DESTDIR/nhsupsclient.sh, respectivamente, como templates.
echo
echo Exemplo para Debian/Ubuntu:
echo
echo $ cp $DESTDIR/nhsupsserver.sh /etc/init.d/nhsupsserver
echo $ cp $DESTDIR/nhsupsclient.sh /etc/init.d/nhsupsclient
echo $ update-rc.d nhsupsserver defaults
echo $ update-rc.d nhsupsclient defaults
